/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif
#include <stdio.h>
#include <stdint.h>        /* Includes uint16_t definition                    */
#include <stdbool.h>       /* Includes true/false definition                  */

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp              */
#include "PWM.h" 
#include "UART.h"
#include "motor_functions.h"
#include <libpic30.h>      // pour le sleep

/******************************************************************************/
/* Global Variable Declaration                                                */
/******************************************************************************/

/* i.e. uint16_t <variable_name>; */
unsigned char Enstop_input = 0;
unsigned char data;
unsigned char test;
/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/

int16_t main(void)
{

    /* Configure the oscillator for the device */
    ConfigureOscillator();

    /* Initialize IO ports and peripherals */
    InitApp();
    inituart();
    /* TODO <INSERT USER APPLICATION CODE HERE> */
    initpwm();
    LATAbits.LATA0 = 0;
    
   
    
    while(1)
    {
        //LATAbits.LATA0 = 1;     
   
        //INTCON2bits.INT0EP = 0;     //rising edge
        Enstop();
        UARTX();
        uart_control_pwm();
  
            //CCP1CON1Lbits.CCPON = 1; 
    }  
}
       