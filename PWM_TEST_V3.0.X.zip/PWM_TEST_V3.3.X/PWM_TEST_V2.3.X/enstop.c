/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include <stdint.h>        /* Includes uint16_t definition                    */
#include <stdbool.h>       /* Includes true/false definition                  */

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp              */
#include "PWM.h" 
#include <libpic30.h>      // pour le sleep

void Enstop (void)
{
    INTCON2bits.INT1EP = 0;     //rising edge
    if(Enstop_input == 1)
    {
        INTCON2bits.INT1EP = 1; //falling edge
            while(Enstop_input == 1)
            //Enstop_input == 1
            {
               CCP1CON1Lbits.CCPON = 0; // turn off PWM   
               /*control working*/
                LATAbits.LATA0 = 0;
                __delay_ms(500);
                LATAbits.LATA0 = 1;
                __delay_ms(500);                   
            }
        CCP1CON1Lbits.CCPON = 1; 
    }        
    LATAbits.LATA0 = 1;
}
