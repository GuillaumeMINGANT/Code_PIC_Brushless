/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include <stdint.h>          /* For uint32_t definition */
#include <stdbool.h>         /* For true/false definition */

#include "user.h"            /* variables/params used by user.c */

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

/* <Initialize variables in user.h and insert code for user algorithms.> */

/* TODO Initialize User Ports/Peripherals/Project here */

void InitApp(void)
{
    /* Setup analog functionality and port direction */
    
    
    TRISAbits.TRISA0 = 0; //Set as output, debugging LED
    ANSAbits.ANSA0 = 0; //Set as digital IO      
    
    TRISBbits.TRISB12 = 1; //Set as input external interrupt
    ANSBbits.ANSB12 = 0; //Set as digital IO
    /* Initialize peripherals */

    /*_______________________________________________________________*/
    /*   USER INTERRUPT   */
   

    /* Initialize peripherals */
    INTCON2bits.INT1EP = 0; //rising edge
    IFS1bits.INT1IF = 0;    //Clear INT0 flag
    IEC1bits.INT1IE = 1;    //Enable INT0 Interrupt
    IPC5bits.INT1IP2 = 1;   //Config INT0 priority bit2
    IPC5bits.INT1IP1 = 1;   //Config INT0 priority bit1
    IPC5bits.INT1IP0 = 1;   //Config INT0 priority bit0
    
    /* Initialize peripherals */
    /*UART1*/
    //U1MODE=0x8800;
   
}

