/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include "PROROK.h"            /* variables/params used by user.c */

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

/* <Initialize variables in user.h and insert code for user algorithms.> */

/* TODO Initialize User Ports/Peripherals/Project here */

void initI2C (void)
{
    /*
    TRISBbits.TRISB2 = 1; //Set as input external interrupt 2 TTL et UART2
    ANSBbits.ANSB2 = 0; //Set as digital IO
    
    TRISBbits.TRISB3 = 1; //Set as input external interrupt 2 TTL et UART2
    ANSBbits.ANSB3 = 0; //Set as digital IO
      */
    
    //IEC3bits.SSP2IE = 
}
