/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include "PROROK.h"            /* variables/params used by user.c */

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

/* <Initialize variables in user.h and insert code for user algorithms.> */

/* TODO Initialize User Ports/Peripherals/Project here */

void initpwm(void)
{
   /* Setup analog functionality and port direction */
    ANSBbits.ANSB8 = 0;     //Set as digital IO
    TRISBbits.TRISB8 = 0;   //Set as output
    
    /* Initialize peripherals */
    
    /* Example 64-3: Setup for Dual Edge Buffered Compare Mode */
    
    /* Set MCCP operating mode */
    
    CCP1CON1Lbits.CCSEL = 0;        // Set MCCP operating mode (OC mode)
    CCP1CON1Lbits.MOD = 0b0101;     // Set mode (Buffered Dual-Compare/PWM mode)
    
    /* Configure MCCP Timebase */
    
    CCP1CON1Lbits.TMR32 = 0;        // Set timebase width (16-bit)
    CCP1CON1Lbits.TMRSYNC = 0;      // Set timebase synchronization (Synchronized)
    CCP1CON1Lbits.CLKSEL = 0b000;   // Set the clock source (Tcy)
    CCP1CON1Lbits.TMRPS = 0b00;     // Set the clock pre-scaler (1:1)
    CCP1CON1Hbits.TRIGEN = 0;       // Set Sync/Triggered mode (Synchronous)
    CCP1CON1Hbits.SYNC = 0b00000;   // Select Sync/Trigger source (Self-sync)
    
    /* Configure MCCP output for PWM signal */
    
    CCP1CON2Hbits.OCBEN = 1;        // Enable desired output signals (OC1B) : pin 17, RB8
    CCP1CON3Hbits.OUTM = 0b000;     // Set advanced output modes (Standard output)
    CCP1CON3Hbits.POLACE = 0;       //Configure output polarity (Active High)
    CCP1TMRL = 0x0000;              //Initialize timer prior to enable module.
    CCP1PRL = 0x9C40;               //Configure timebase period 20ms
    //CCP1PRH = 0x0001;              
    
    CCP1RA = 0x1000;                // Set the rising edge compare value
    CCP1RB = 0x1FA0;                // Set the falling edge compare value 1ms
    
    CCP1CON1Lbits.CCPON = 1;        // Turn on MCCP module
    
}


