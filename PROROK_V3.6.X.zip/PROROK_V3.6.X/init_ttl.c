/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include "PROROK.h"            /* variables/params used by user.c */

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

/* <Initialize variables in user.h and insert code for user algorithms.> */

/* TODO Initialize User Ports/Peripherals/Project here */

void initTmr1(void)
{
    /* Initialize peripherals INT2 for TTL*/
    //init TTL
    T1CONbits.TON = 1;            //    T1CONbits.TON = 1;
    T1CONbits.TCKPS0 = 1;
    T1CONbits.TCKPS1 = 0;          // Prescaler 1:8

    IEC0bits.T1IE = 1; //set overflow interupt
    IFS0bits.T1IF = 0; //Clear INT0 flag
}
void inicapt(void)
{
    TRISBbits.TRISB12 = 1; //Set as input external interrupt 1
    ANSBbits.ANSB12 = 0; //Set as digital IO
    
    IEC1bits.INT2IE = 1;
    
    IFS1bits.INT2IF = 0;
    
    IPC7bits.INT2IP0 = 0;
    IPC7bits.INT2IP1 = 1;
    IPC7bits.INT2IP2 = 0;
}