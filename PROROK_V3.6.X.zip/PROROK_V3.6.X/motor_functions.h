/* 
 * File:   motor_functions.h
 * Author: rapha
 *
 * Created on 24 mars 2019, 19:43
 */

#ifndef MOTOR_FUNCTIONS_H
#define	MOTOR_FUNCTIONS_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* MOTOR_FUNCTIONS_H */

void initpwm(void);

void uart_control_pwm(void);

void blink_test(void);

void motor_acceleration(void);

void rigth_motor_rotation(void);         

void stop_motor(void);                   

void left_motor_rotation(void);

void motor_deceleration(void);
