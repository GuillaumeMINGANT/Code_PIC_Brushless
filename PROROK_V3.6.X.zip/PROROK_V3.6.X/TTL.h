/* 
 * File:   TTL.h
 * Author: rapha
 *
 * Created on 9 avril 2019, 10:33
 */

#ifndef TTL_H
#define	TTL_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* TTL_H */

void initTmr1(void);
void inicapt(void);
void mesure_vitesse(void);