void inituart(void);
void UARTX(void);
void short_to_ascii(unsigned char s[10], unsigned short shortt);

