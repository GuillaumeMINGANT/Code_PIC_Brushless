
/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include "PROROK.h" /*TOUT*/

extern U8 Enstop_input;

void Enstop (void)
{
        INTCON2bits.INT0EP = 0;     //rising edge
        if(Enstop_input == 1)
        {
            INTCON2bits.INT0EP = 1; //falling edge
                while(Enstop_input == 1)
                //Enstop_input == 1
                {
                   CCP1CON1Lbits.CCPON = 0; // turn off PWM
                   blink_test();
                }
        }
        CCP1CON1Lbits.CCPON = 1;
}
