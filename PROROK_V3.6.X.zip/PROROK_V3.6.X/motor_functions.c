/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
#include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include "PROROK.h" /*TOUT*/

extern U16 vitesse;
extern U16 frequence;
extern U8 data;
extern U8 vitesse_ascii[];
extern U8 frequence_ascii[];

void blink_test(void)
{
           /*control working*/
           LATAbits.LATA0 = 0;
           __delay_ms(500);
           LATAbits.LATA0 = 1;
           __delay_ms(500); 
}

void motor_acceleration(void)
{
    //CCP1RA = 0x1000;                // Set the rising edge compare value
    /*if(CCP1RB<0x7333)
    {
        CCP1RB += 0x0CCD;
    }*/   
}

void rigth_motor_rotation(void)
{
    CCP1RB = 0x1FA0 ;  // Set the falling edge compare value
}                         

void stop_motor(void)
{   
    CCP1RB = 0x2770; 
}

void left_motor_rotation(void)
{
    CCP1RB = 0x2F40;
}

void motor_deceleration(void)
{    
    //CCP1RA = 0x1000;                // Set the rising edge compare value
    /*if(CCP1RB>0x1CCD){
        CCP1RB -= 0x0CCD;
    
    }*/
}

void uart_control_pwm(void)
{
        switch(data)
            {
                case '8':
                    motor_acceleration();
                    break;
                    
                case '6':
                    rigth_motor_rotation(); 
                    break;
                    
                case '5': 
                    stop_motor(); 
                    break;
                    
                case '4':
                    left_motor_rotation();
                    break;
                    
                case '2':
                    motor_deceleration();
                    break;
                case 's':
                    screen_menu();
                    data = 0;
                    break;
                case 'a':
                    accel();
                    data = 0;
                    break;
                case 'm':
                    screen_motor();
                    data = 0;
                    break;
                case 'v':
                    freq();
                    data = 0;
                    break;
                default :  
                 
                    break;
            }
    } 