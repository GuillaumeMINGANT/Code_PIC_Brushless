#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include "PROROK.h"


extern U16 frequence;
extern U8 data;
extern U8 vitesse_ascii[10];
extern U8 frequence_ascii[10];

void Transmit(unsigned char data){
    
     while (U2STAbits.UTXBF == 1){}  //tant que le buffer est full on attend
     __delay_ms(1);
     U2TXREG = data;

}

void display(unsigned char s[])
{
    U16 i;
    U8 tab[30];
    U16 length = sizeof(tab);
    for(i=0; i < length; i++)
    {
        Transmit(s[i]);
    }
    
}

void accel(void)
{
    U8 tab[] = "*******ACCELEROMETRE*******\r\n";

    U8 tab1[] = "* COORDONNEE SUR X  [ X ] G\r\n";

    U8 tab2[] = "* COORDONNEE SUR Y  [ X ] G\r\n";

    U8 tab3[] = "* COORDONNEE SUR Z  [ X ] G\r\n";

    display(tab);
    display(tab1);
    display(tab2);
    display(tab3);   
}

void freq(void)
{
    U8 tab[] = "*********FREQUENCE*********\r\n";

    U8 tab1[] = "LA FREQUENCE EST  EN  HZ :\r\n";

    //U8 tab2[] = "** LA VITESSE EST EN M/S :\r\n";

    display(tab);
    display(tab1);
    short_to_ascii(frequence_ascii, frequence);
    //display(tab2);
    
}

void screen_motor(void)
{
    U8 tab[] = "***********MOTOR***********\r\n";

    U8 tab1[] = "POUR TOURNER A DROITE [ 6 ]\r\n";

    U8 tab2[] = "*** ARRETER LE MOTEUR [ 5 ]\r\n";

    U8 tab3[] = "POUR TOURNER A GAUCHE [ 4 ]\r\n";

    display(tab);
    display(tab1);
    display(tab2);
    display(tab3);   
}

void screen_menu(void)
{
    U8 tab[30] = "***********MENU***********\r\n";

    U8 tab1[30] = "ACCELEROMETRE  TAPEZ  [ A ]\r\n";

    U8 tab2[30] = "***** MOTEUR  TAPEZ   [ M ]\r\n";

    U8 tab3[30] = "**** VITESSE  TAPEZ   [ V ]\r\n";

    display(tab);
    display(tab1);
    display(tab2);
    display(tab3);
}


