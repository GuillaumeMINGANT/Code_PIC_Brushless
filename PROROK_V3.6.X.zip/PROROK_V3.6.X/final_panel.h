/* 
 * File:   final_panel.h
 * Author: rapha
 *
 * Created on 10 mai 2019, 11:06
 */

#ifndef FINAL_PANEL_H
#define	FINAL_PANEL_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* FINAL_PANEL_H */

void Transmit(unsigned char data);
void screen_menu(void);
void display(unsigned char s[]);
void screen_motor(void);
void accel(void);
void freq(void);