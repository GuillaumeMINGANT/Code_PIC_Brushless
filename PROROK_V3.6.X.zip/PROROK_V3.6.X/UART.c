#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include "PROROK.h" /*TOUT*/

extern U8 data;
extern U8 test;
extern U16 vitesse;
extern U16 frequence;
extern U8 vitesse_ascii[10];
extern U8 frequence_ascii[10];
extern U8 s[3];

void UARTX()
{
    
    if (test)
    {
     while (U2STAbits.UTXBF == 1){}  //tant que le buffer est full on attend
     __delay_ms(1);
     U2TXREG = data;
     test = 0;     
    }
}

void short_to_ascii(U8 s[10], U16 test)
{
    s[2] = test%10;
    test -= test%10;
    s[1] = test%100;
    test -= test%100;
    s[0] = test;
    s[1] = s[1]/10;
    s[0] = s[0]/100;
    s[0] = s[0] + 0x30;
    s[1] = s[1] + 0x30;
    s[2] = s[2] + 0x30;
    display(s);
}
