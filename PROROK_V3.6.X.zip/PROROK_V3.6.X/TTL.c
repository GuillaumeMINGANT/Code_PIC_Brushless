/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
#include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include "PROROK.h" /*TOUT*/

extern float F;
extern U16 vitesse;
extern U16 frequence;
extern U8 T1OV;

void mesure_vitesse(void)
{    
    F=TMR1;
    TMR1 = 0;
    frequence = 1/((F+(65535*T1OV))/500000); //1/((F2+(65535 * T1OV))/(4000000/8));
    //vitesse = 1 / ()
    T1OV = 0; 
}