/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include "PROROK.h" /*TOUT*/

/******************************************************************************/
/* Global Variable Declaration                                                */
/******************************************************************************/

/* i.e. uint16_t <variable_name>; */
U8 Enstop_input = 0;
U8 data;
U8 test;
float F;
U16 vitesse;
U16 frequence;
U8 vitesse_ascii[10];
U8 frequence_ascii[10];
U8 T1OV;
U8 check;
/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/

int16_t main(void)
{

    /* Configure the oscillator for the device */
    ConfigureOscillator();

    /* Initialize IO ports and peripherals */
    InitApp();
    initpwm();
    inituart();
    initTmr1();
    inicapt();
    initI2C();
    /* TODO <INSERT USER APPLICATION CODE HERE> */
    
    LATAbits.LATA0 = 0;
    
    while(1)
    {
        //LATAbits.LATA0 = 1;     
        //INTCON2bits.INT0EP = 0;     //rising edge
        Enstop();
        UARTX();
        uart_control_pwm();
            //CCP1CON1Lbits.CCPON = 1; 
    }  
}
       