/* 
 * File:   I2C.h
 * Author: rapha
 *
 * Created on 9 avril 2019, 11:34
 */

#ifndef I2C_H
#define	I2C_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* I2C_H */

void initI2C(void);
void I2C(void);