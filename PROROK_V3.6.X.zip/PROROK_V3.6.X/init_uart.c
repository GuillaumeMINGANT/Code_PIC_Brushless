 /******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include "PROROK.h"            /* TOUT */


void inituart(void)
{
    /* Setup analog functionality and port direction */
    /*TRISBbits.TRISB2=1;
    TRISBbits.TRISB7=0;

    ANSBbits.ANSB2=0;
    ANSBbits.ANSB7=0;    
    
    U1MODEbits.UARTEN=1; // UARTx is enabled; all UARTx pins are controlled by UARTx, as defined by UEN<1:0>
    U1MODEbits.USIDL=0;  //UARTx Don't Stop in Idle Mode
    U1MODEbits.IREN=0;   // IrDA encoder and decoder are disabled
    U1MODEbits.RTSMD=1;  //UxRTS pin is in Simplex mode ?
    U1MODEbits.UEN1=0;   //00 = UxTX and UxRX pins are enabled and used;
    U1MODEbits.UEN0=0;   // UxCTS and UxRTS/UxBCLK pins are controlled by port
    U1MODEbits.WAKE=0;   // No wake-up is enabled
    U1MODEbits.LPBACK=0; //Loopback mode is disabled ???
    U1MODEbits.ABAUD=0;  //Baud rate measurement is disabled or completed ???
    U1MODEbits.URXINV=0; // UARTx Receive Polarity Inversion bit, Idle state is ?1?
    U1MODEbits.BRGH=0;   // generates 16 clocks per bit period (16x baud clock, Standard mode)
    U1MODEbits.PDSEL1=0; // 00 = 8-bit data, no parity
    U1MODEbits.PDSEL0=0;
    U1MODEbits.STSEL=0;  //0 = One Stop bit
    //U1STA=0x24D0;
    U1STAbits.UTXISEL1=0; //Interrupt when the last character is shifted out of 
    U1STAbits.UTXISEL0=1; //the Transmit Shift Register; all transmit operations are completed
    U1STAbits.UTXINV=0;   //IrDA� Encoder Transmit Polarity Inversion bit depending of IREN
    U1STAbits.UTXBRK=0;   // Sync Break transmission is disabled or completed
    U1STAbits.UTXEN=1;    //Transmit is enabled; UxTX pin is controlled by UARTx
    U1STAbits.URXISEL1=0; //0x = Interrupt is set when any character is received and transferred from the RSR to the receive buffer; receive buffer has one or more characters
    U1STAbits.ADDEN=0;    //Address Detect mode is disabled
    U1BRG=25; //decimal bd � 9615 
    horloge 8MHZ 
    // pra default dans le confbits.c � verifier avec debadier
    
    interrupt sur le rx*/
    /*IFS0bits.U1RXIF=1; //clear flag
    IEC0bits.U1RXIE=1; //eneable interrupt
    
    IPC2bits.U1RXIP2=1;
    IPC2bits.U1RXIP1=1;
    IPC2bits.U1RXIP0=0;
    */
    
    //________________________
    /* Setup analog functionality and port direction */
    TRISBbits.TRISB1=1;    
    TRISBbits.TRISB0=0;

    ANSBbits.ANSB0=0;
    ANSBbits.ANSB1=0;    
    
    U2MODEbits.UARTEN=1; // UARTx is enabled; all UARTx pins are controlled by UARTx, as defined by UEN<1:0>
    U2MODEbits.USIDL=0;  //UARTx Don't Stop in Idle Mode
    U2MODEbits.IREN=0;   // IrDA encoder and decoder are disabled
    U2MODEbits.RTSMD=1;  //UxRTS pin is in Simplex mode ?
    U2MODEbits.UEN1=0;   //00 = UxTX and UxRX pins are enabled and used;
    U2MODEbits.UEN0=0;   // UxCTS and UxRTS/UxBCLK pins are controlled by port
    U2MODEbits.WAKE=0;   // No wake-up is enabled
    U2MODEbits.LPBACK=0; //Loopback mode is disabled ???
    U2MODEbits.ABAUD=0;  //Baud rate measurement is disabled or completed ???
    U2MODEbits.URXINV=0; // UARTx Receive Polarity Inversion bit, Idle state is ?1?
    U2MODEbits.BRGH=0;   // generates 16 clocks per bit period (16x baud clock, Standard mode)
    U2MODEbits.PDSEL1=0; // 00 = 8-bit data, no parity
    U2MODEbits.PDSEL0=0;
    U2MODEbits.STSEL=0;  //0 = One Stop bit
    //U1STA=0x24D0;
    U2STAbits.UTXISEL1=0; //Interrupt when the last character is shifted out of 
    U2STAbits.UTXISEL0=1; //the Transmit Shift Register; all transmit operations are completed
    U2STAbits.UTXINV=0;   //IrDA� Encoder Transmit Polarity Inversion bit depending of IREN
    U2STAbits.UTXBRK=0;   // Sync Break transmission is disabled or completed
    U2STAbits.UTXEN=1;    //Transmit is enabled; UxTX pin is controlled by UARTx
    U2STAbits.URXISEL1=0; //0x = Interrupt is set when any character is received and transferred from the RSR to the receive buffer; receive buffer has one or more characters
    U2STAbits.ADDEN=0;    //Address Detect mode is disabled
    U2BRG=25; //decimal bd � 9615 
    /*horloge 8MHZ */
    // pra default dans le confbits.c � verifier avec debadier
    
    /* interrupt sur le rx*/
    IFS1bits.U2RXIF=1; //clear flag
    IEC1bits.U2RXIE=1; //eneable interrupt
    
    IPC7bits.U2RXIP2=1;
    IPC7bits.U2RXIP1=1;
    IPC7bits.U2RXIP0=0;
    
}