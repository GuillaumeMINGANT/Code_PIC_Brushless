void send(char data);

