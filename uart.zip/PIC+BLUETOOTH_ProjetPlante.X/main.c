/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include <stdint.h>        /* Includes uint16_t definition                    */
#include <stdbool.h>       /* Includes true/false definition                  */

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp              */
#include "libpic30.h"
#include "uart.h"
/******************************************************************************/
/* Global Variable Declaration                                                */
/******************************************************************************/

/* i.e. uint16_t <variable_name>; */

/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/

unsigned char data;
unsigned char test;
int16_t main(void)
{

    /* Configure the oscillator for the device */
    ConfigureOscillator();

    /* Initialize IO ports and peripherals */
    InitApp();

    /* TODO <INSERT USER APPLICATION CODE HERE> */
    
    LATAbits.LATA0 = 0;
    
    U1TXREG ='F';
    U1TXREG ='R';
    U1TXREG ='C';
    
    while(1)
    {
       
      LATAbits.LATA0 = 1;
       // pour ne pas faire d'interrupt !!!
       
         //test=1;
        if (test){
           /*
            while (U1STAbits.UTXBF == 1){}  //tant que le buffer est full on attend
              __delay_ms(1);
              U1TXREG=data;*/
            send(data);
            test=0;
        }
       LATAbits.LATA0 = 0;
       LATAbits.LATA0 = 1;
    }
    
}
