/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include <stdint.h>          /* For uint32_t definition */
#include <stdbool.h>         /* For true/false definition */

#include "user.h"            /* variables/params used by user.c */

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

/* <Initialize variables in user.h and insert code for user algorithms.> */

/* TODO Initialize User Ports/Peripherals/Project here */

void InitApp(void)
{
    /* Setup analog functionality and port direction */
    TRISBbits.TRISB2=1;
    TRISBbits.TRISB7=0;
    TRISAbits.TRISA0=0;
    ANSBbits.ANSB2=0;
    ANSBbits.ANSB7=0;
    ANSAbits.ANSA0=0;
    /* Initialize peripherals */
    /*UART1*/
    //U1MODE=0x8800;
    U1MODEbits.UARTEN=1;
    U1MODEbits.USIDL=0;
    U1MODEbits.IREN=0;
    U1MODEbits.RTSMD=1;
    U1MODEbits.UEN1=0;
    U1MODEbits.UEN0=0;
    U1MODEbits.WAKE=0;
    U1MODEbits.LPBACK=0;
    U1MODEbits.ABAUD=0;
    U1MODEbits.URXINV=0;
    U1MODEbits.BRGH=0;
    U1MODEbits.PDSEL1=0;
    U1MODEbits.PDSEL0=0;
    U1MODEbits.STSEL=0;
    //U1STA=0x24D0;
    U1STAbits.UTXISEL1=0;
    U1STAbits.UTXINV=0;
    U1STAbits.UTXISEL0=1;
    U1STAbits.UTXBRK=0;
    U1STAbits.UTXEN=1;
    U1STAbits.URXISEL1=0;
    U1STAbits.ADDEN=0;
    U1BRG=25; //decimal bd � 9615 
    /*horloge 8MHZ */
    // pra default dans le confbits.c � verifier avec debadier
    /*interrupt sur le rx*/
    IFS0bits.U1RXIF=1; //clear flag
    IEC0bits.U1RXIE=1; //eneable interrupt
    IPC2bits.U1RXIP2=1;
    IPC2bits.U1RXIP1=1;
    IPC2bits.U1RXIP0=1;
}

